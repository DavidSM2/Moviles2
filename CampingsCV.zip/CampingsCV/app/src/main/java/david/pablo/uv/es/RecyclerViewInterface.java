package david.pablo.uv.es;

public interface RecyclerViewInterface {
        void onItemClick(int position);
}
